import 'package:expenses_manager/features/add_expense/data/model/expense_model.dart';

List<ExpenseModel> filteredTransactions = [];

